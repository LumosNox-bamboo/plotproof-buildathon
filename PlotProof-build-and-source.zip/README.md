# PlotProof

PlotProof is a browser-based preflight check for chart palettes. It compares each bar color with the plot background, previews the result in grayscale, and offers a one-click repair for colors below 3:1.

## Try it

Open `dist/PlotProof.html` in a modern browser. It works offline. No account, installation, or data upload is required.

1. Start with the sample palette. One of its three bars meets the target.
2. Select **Fix low contrast**. All three bars now meet the target. The passing color is preserved.
3. Select **Grayscale** and toggle patterns to compare readability without hue.
4. Change a hex color or the background, then select **Download report** for the current ratios and pass/fail results.

The chart uses synthetic follow-up completion values. The check covers bar fills against the plot background. Review text, adjacent graphical boundaries, and the final exported figure separately. See the [WCAG 2.2 guidance for non-text contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html).

## Source and tests

The split HTML, CSS, and JavaScript source files are in `dist/`. Run `python3 -m http.server 8080 --bind 127.0.0.1 --directory dist` to serve the split files. Run `node --test contrast.test.mjs` for the contrast, input, adjustment, and grayscale checks.
