import assert from 'node:assert/strict';
import { test } from 'node:test';
import { adjustContrast, contrast, grayscale, minimumContrast, normalizeHex, readableInk } from './dist/contrast.mjs';

test('uses WCAG relative luminance and handles black and white extremes', () => {
    assert.equal(contrast('#000000', '#FFFFFF'), 21);
    assert.equal(contrast('#236F5B', '#236F5B'), 1);
    assert.equal(contrast('#236F5B', '#FFFFFF'), contrast('#FFFFFF', '#236F5B'));
    assert.ok(Math.abs(contrast('#777777', '#FFFFFF') - 4.478) < 0.001);
});

test('parses narrow and wide hex and rejects missing or extra characters', () => {
    assert.equal(normalizeHex(' #2a5 '), '#22AA55');
    assert.equal(normalizeHex('123abc'), '#123ABC');
    assert.equal(normalizeHex('#12'), null);
    assert.equal(normalizeHex('#AED00277'), null);
});

test('repairs low contrast regardless of background lightness', () => {
    for (const [color, bg] of [['#E4AE59','#FFFFFF'], ['#222333','#141414'], ['#7D8379','#7E7E7E']]) {
        assert.ok(contrast(color, bg) < minimumContrast);
        const repaired = adjustContrast(color, bg);
        assert.ok(contrast(repaired, bg) >= minimumContrast);
        assert.equal(adjustContrast(repaired, bg), repaired);
    }
    assert.equal(adjustContrast('#236F5B', '#FFFFFF'), '#236F5B');
});

test('preserves grayscale lightness to within 8-bit rounding', () => {
    assert.equal(grayscale('#000000'), '#000000');
    assert.equal(grayscale('#AAAAAA'), '#AAAAAA');
    const color = '#236F5B';
    const gray = grayscale(color);
    assert.match(gray, /^#([0-9A-F]{2})\1\1$/);
    assert.ok(Math.abs(contrast(gray, '#FFFFFF') - contrast(color, '#FFFFFF')) < 0.03);
});

test('chooses readable light or dark ink against the preview background', () => {
    assert.equal(readableInk('#FFFFFF'), '#000000');
    assert.equal(readableInk('#222222'), '#FFFFFF');
    assert.ok(contrast(readableInk('#777777'), '#777777') >= 4.5);
});
